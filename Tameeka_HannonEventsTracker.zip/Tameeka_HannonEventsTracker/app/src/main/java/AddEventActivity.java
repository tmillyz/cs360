package com.example.tameeka_hannoneventstracker;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    private EditText eventNameInput;
    private EditText eventDateInput;
    private EditText eventTimeInput;
    private EditText eventDescriptionInput;
    private Button saveEventButton;
    private Button cancelButton;
    private EventDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Initialize the database helper
        dbHelper = new EventDatabaseHelper(this);

        // Find views
        eventNameInput = findViewById(R.id.eventNameInput);
        eventDateInput = findViewById(R.id.eventDateInput);
        eventTimeInput = findViewById(R.id.eventTimeInput);
        eventDescriptionInput = findViewById(R.id.eventDescriptionInput);
        saveEventButton = findViewById(R.id.saveEventButton);
        cancelButton = findViewById(R.id.cancelButton);

        // Set click listener for save button
        saveEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveEvent();
            }
        });

        // Set click listener for cancel button
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancel();
            }
        });
    }

    private void saveEvent() {
        // Get the input values
        String name = eventNameInput.getText().toString().trim();
        String date = eventDateInput.getText().toString().trim();
        String time = eventTimeInput.getText().toString().trim();
        String description = eventDescriptionInput.getText().toString().trim();

        // Validate input
        if (name.isEmpty() || date.isEmpty() || time.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save the event to the database
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("date", date);
        values.put("time", time);
        values.put("description", description);

        long newRowId = db.insert("events", null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Event saved successfully", Toast.LENGTH_SHORT).show();
            // Return to the previous screen
            finish();
        } else {
            Toast.makeText(this, "Error saving event", Toast.LENGTH_SHORT).show();
        }
    }

    private void cancel() {
        // Return to the previous screen without saving
        finish();
    }
}
