package com.example.tameeka_hannoneventstracker;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class EditEventActivity extends AppCompatActivity {

    private EditText etEventName, etEventDate, etEventTime, etEventDescription;
    private Button btnSaveChanges, btnCancel;
    private EventDatabaseHelper dbHelper;
    private long eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        etEventName = findViewById(R.id.etEventName);
        etEventDate = findViewById(R.id.etEventDate);
        etEventTime = findViewById(R.id.etEventTime);
        etEventDescription = findViewById(R.id.etEventDescription);
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnCancel = findViewById(R.id.btnCancel);

        dbHelper = new EventDatabaseHelper(this);

        // Assume eventId is passed through Intent
        eventId = getIntent().getLongExtra("eventId", -1);
        loadEventDetails();

        btnSaveChanges.setOnClickListener(v -> saveChanges());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void loadEventDetails() {
        // Load event details from database and set to EditTexts
        // Code to be implemented
    }

    private void saveChanges() {
        String name = etEventName.getText().toString();
        String date = etEventDate.getText().toString();
        String time = etEventTime.getText().toString();
        String description = etEventDescription.getText().toString();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("date", date);
        values.put("time", time);
        values.put("description", description);

        dbHelper.getWritableDatabase().update("events", values, "_id=?", new String[]{String.valueOf(eventId)});
        finish();
    }
}
