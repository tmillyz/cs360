package com.example.tameeka_hannoneventstracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EventDetailActivity extends AppCompatActivity {

    private TextView tvEventName, tvEventDate, tvEventTime, tvEventDescription;
    private Button btnEditEvent, btnDeleteEvent;
    private EventDatabaseHelper dbHelper;
    private long eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        tvEventName = findViewById(R.id.tvEventName);
        tvEventDate = findViewById(R.id.tvEventDate);
        tvEventTime = findViewById(R.id.tvEventTime);
        tvEventDescription = findViewById(R.id.tvEventDescription);
        btnEditEvent = findViewById(R.id.btnEditEvent);
        btnDeleteEvent = findViewById(R.id.btnDeleteEvent);

        dbHelper = new EventDatabaseHelper(this);

        // Assume eventId is passed through Intent
        eventId = getIntent().getLongExtra("eventId", -1);
        loadEventDetails();

        btnEditEvent.setOnClickListener(v -> {
            Intent intent = new Intent(EventDetailActivity.this, EditEventActivity.class);
            intent.putExtra("eventId", eventId);
            startActivity(intent);
        });

        btnDeleteEvent.setOnClickListener(v -> deleteEvent());
    }

    private void loadEventDetails() {
        // Load event details from database and set to TextViews
        // Code to be implemented
    }

    private void deleteEvent() {
        dbHelper.getWritableDatabase().delete("events", "_id=?", new String[]{String.valueOf(eventId)});
        finish();
    }
}
