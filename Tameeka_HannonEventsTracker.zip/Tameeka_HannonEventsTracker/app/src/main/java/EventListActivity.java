package com.example.tameeka_hannoneventstracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class EventListActivity extends AppCompatActivity {

    private Button btnAddEvent;
    private ListView lvEvents;
    private EventDatabaseHelper dbHelper;
    private SimpleCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        btnAddEvent = findViewById(R.id.btnAddEvent);
        lvEvents = findViewById(R.id.lvEvents);

        dbHelper = new EventDatabaseHelper(this);
        Cursor cursor = dbHelper.getReadableDatabase().query("events", null, null, null, null, null, null);

        String[] fromColumns = {"name", "date"};
        int[] toViews = {R.id.tvEventName, R.id.tvEventDate};

        adapter = new SimpleCursorAdapter(this, R.layout.event_list_item, cursor, fromColumns, toViews, 0);
        lvEvents.setAdapter(adapter);

        btnAddEvent.setOnClickListener(v -> {
            Intent intent = new Intent(EventListActivity.this, AddEventActivity.class);
            startActivity(intent);
        });
    }
}
